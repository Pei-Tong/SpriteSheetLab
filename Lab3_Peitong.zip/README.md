# SpriteSheetLab

## Overview
A React Native game development project that demonstrates the implementation of sprite animations and physics using matter.js and rn-sprite-sheet.
